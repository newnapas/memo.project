global.__DEV__ = true

require('./modules/__tests__/serverRendering-test')
