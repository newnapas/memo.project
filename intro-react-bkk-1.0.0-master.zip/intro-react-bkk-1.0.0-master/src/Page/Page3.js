import React, { Component } from 'react';

export default class Page3 extends Component {
  render() {
    return (
      <div>
        <h1>Page3</h1>
      </div>
    );
  }
}
